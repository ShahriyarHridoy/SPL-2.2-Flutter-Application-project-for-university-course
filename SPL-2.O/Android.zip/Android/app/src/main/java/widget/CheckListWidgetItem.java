package widget;

public class CheckListWidgetItem {
    public String heading;
}
